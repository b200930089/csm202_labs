class Savings {
    private String name;
    private String currency;
    private double annualInterest;
    private int durationMonths;
    private double initialBalance;

    public Savings(String name, String currency, double annualInterest, int durationMonths, double initialBalance) {
        this.name = name;
        this.currency = currency;
        this.annualInterest = annualInterest;
        this.durationMonths = durationMonths;
        this.initialBalance = initialBalance;
    }

    private double savingscalcaccrued() {
        return initialBalance * (annualInterest / 12) * durationMonths / 100;
    }

    private double savingscalc() {
        return initialBalance + savingscalcaccrued();
    }

    public void savingsreport() {
        double accruedInterest = savingscalcaccrued();
        double finalBalance = savingscalc();

        System.out.printf("Та \"%s\"-д %,.1f%s-ийг %d сарын хугацаатай, жилийн %.1f%%-ийн хүүтэй хадгалуулбал:\n", 
                          name, initialBalance, currency, durationMonths, annualInterest);
        
        System.out.printf("Хадгаламжийн үлдэгдэл: %,.1f%s болно.\n", finalBalance, currency);
        
        System.out.printf("Хуримтлагдсан хүү: %,.1f%s байна.\n", accruedInterest, currency);
    }
}
