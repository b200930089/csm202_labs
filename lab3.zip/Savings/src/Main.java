import java.util.Scanner;
import java.util.Locale;
public class Main {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in).useLocale(Locale.US);

        System.out.print("Хадгаламжийн нэр оруулна уу: ");
        String name = scanner.nextLine();

        System.out.print("Валют оруулна уу: ");
        String currency = scanner.next();

        System.out.print("Жилийн хүү оруулна уу (жишээ нь 13.1): ");
        double annualInterest = scanner.nextDouble();

        System.out.print("Хадгалах хугацаа (сараар): ");
        int durationMonths = scanner.nextInt();

        System.out.print("Эхний үлдэгдэл оруулна уу: ");
        double initialBalance = scanner.nextDouble();

        Savings s = new Savings(name, currency, annualInterest, durationMonths, initialBalance);
        
        System.out.println("\n--- ҮР ДҮН ---");
        s.savingsreport();
        
        scanner.close();
    }
}
